function toggleDiv(targetId) {  
    var toggleableDivs = document.getElementsByClassName("item-2");  
    for (var i = 0; i < toggleableDivs.length; i++) {  
        toggleableDivs[i].style.display = "none";  
    }  
    var targetDiv = document.getElementById(targetId);  
    if (targetDiv) {  
        targetDiv.style.display = "block";  
    }  
}